function reloadPage(action) {
    location.reload()
}
